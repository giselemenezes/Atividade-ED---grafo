import queue

class Graph:        
    def __init__(self, n):
        self.num_vertices = n
        self.matrix = [[0 for _ in range(n)] for _ in range(n)]
        self.list = [[] for _ in range(n)]

    def add_edge(self, u, v):
        #Adiciona uma aresta entre os vértices u e v
        self.matrix[u][v] = 1 
        self.matrix[v][u] = 1
        self.list[u].append(v)
        self.list[v].append(u)

    def print(self):       
        #Imprime a matriz de adjacência e a lista de adjacência do grafo
        print("Matriz de Adjacência:")
        for row in self.matrix:
            print(row)
        print("Lista de Adjacência:")
        for i, neighbors in enumerate(self.list):
            print(f"Vértice {i}: {neighbors}")

    def bfs(self, source, target):
        #Calcula o caminho mais curto entre esses vértices usando BFS.
        dist = [-1 for _ in range(self.num_vertices)]
        ant = [-1 for _ in range(self.num_vertices)]
        isVisited = [False for _ in range(self.num_vertices)]
        Q = queue.Queue()
        Q.put(source)
        isVisited[source] = True
        dist[source] = 0

        while not Q.empty():
            p = Q.get()

            for v in self.list[p]:
                if not isVisited[v]:
                    dist[v] = dist[p] + 1
                    ant[v] = p
                    Q.put(v)
                    isVisited[v] = True
                    if v == target:
                        return self.reconstruct_path(ant, source, target)

        return None

    def dfs(self, source, target):
        #Explora os vértices em profundidade e retorna o caminho se encontrar o vértice de destino, usando pilha.
        visited = [False for _ in range(self.num_vertices)]
        stack = []
        stack.append(source)
        visited[source] = True

        while stack:
            vertex = stack.pop()

            for v in self.list[vertex]:
                if not visited[v]:
                    stack.append(v)
                    visited[v] = True

                    if v == target:
                        return self.reconstruct_path(visited, source, target)

        return None

    def reconstruct_path(self, ant, source, target):
        #Reconstrói o caminho a partir das informações coletadas durante a busca
        path = []
        current = target

        while current != -1:
            path.insert(0, current)
            current = ant[current]

        if path[0] == source:
            return path
        else:
            return None

def read_graph_from_file(file_path):
    #Lê um grafo a partir de um arquivo.
    with open(file_path, 'r') as file:
        lines = file.readlines()
        num_vertices = int(lines[0])
        g = Graph(num_vertices)
        
        for line in lines[1:]:
            u, v = map(int, line.strip().split())
            g.add_edge(u, v)
        
        return g

#Exemplo de implementação:

if __name__ == "__main__":
    #Carregando o grafo a partir de um arquivo
    graph = load_graph_from_file("grafo.txt")
    graph.print()

    #Executando BFS para encontrar um caminho entre dois vértices
    source = 0
    target = 3
  
    bfs_path = bfs(graph, source, target)
    if bfs_path:
        print(f"Caminho BFS de {source} para {target}: {bfs_path}")
    else:
        print(f"Não há caminho entre {source} e {target}.")

    #Executando DFS para encontrar um caminho entre dois vértices
    dfs_path = dfs(graph, source, target)
    if dfs_path:
        print(f"Caminho DFS de {source} para {target}: {dfs_path}")
    else:
        print(f"Não há caminho entre {source} e {target}.")
